import pandas as pd
import json
import nltk
import re, string, unicodedata
import numpy as np
import random
from nltk.corpus import wordnet as wn
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import stopwords

import pprint
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import recall_score, precision_score
import pickle


pp = pprint.PrettyPrinter()
lm1 = WordNetLemmatizer()

### input file required
all_data = 'data.json'

### files generated and used
train_data = 'assets/train_data.xlsx'
intent_reply_data = 'assets/intent_reply.xlsx'
intent_encodngs = 'assets/intent_encodngs.xlsx'
clf_save_file = 'assets/model.pickle'
vectorizer1 = 'assets/vectorizer1.pickle'

stops = list(set(stopwords.words('english')))

def extract():
    with open(all_data,'r+') as f:                 
    # with open('sample.json','r+') as f:    
        dict1 = json.loads(f.read())

    dict1 = dict1['intents']
    # pp.pprint(dict1)

    df = pd.DataFrame()
    df_ans= pd.DataFrame()
    for d1 in dict1:
        temp_df = pd.DataFrame()
        temp_df_ans = pd.DataFrame()
        temp_df['Qn'] = d1['text']
        temp_df_ans['ans'] = d1['responses']

        temp_df['intent'] = d1['intent']
        temp_df_ans['intent'] = d1['intent']

        df = df.append(temp_df,ignore_index=False)
        df_ans = df_ans.append(temp_df_ans,ignore_index=False)

    print('df:')
    print(df.head(10))
    print('df_ans:')
    print(df_ans.head(10))
    df.to_excel(train_data,index=False)
    df_ans.to_excel(intent_reply_data,index=False)
    return df,df_ans


def clean_sents(s1):
    print(s1)
    s1 = str(s1).replace('-',' ')
    patt1 = r"[^\w\s]"
    s1 = re.sub(patt1,'',s1)
    print('s1 = ',s1)
    patt2 = r"\s+"
    s1 = re.sub(patt2,' ',s1)
    s1 = s1.strip()
    if s1 =='':
        return np.nan
    return s1


def lm_each(sent1):
    sent1 = sent1.lower()
    print('sent1 = ',sent1)
    words = nltk.word_tokenize(sent1)
    print(words)
    words2 = [lm1.lemmatize(x) for x in words]
    # return words2
    print('words2 = ',words2)
    sent2 = ' '.join(words2)
    return sent2

def preprocess_data():
    df = pd.read_excel(train_data)
    # df_ans = pd.read_excel(intent_reply_data)
    # df >> intent, entity
    df['Qn'] = df['Qn'].apply(clean_sents)
    df['Qn'] = df['Qn'].apply(lm_each)
    X_sents = df['Qn'].values.tolist()
    y_intents = df['intent'].values.tolist()
    print('X_sents')
    print(X_sents)
    return X_sents,y_intents

    

def vectorize_sents(X_sents,max_features=30,fit=False):
    if fit:
        vec1 = TfidfVectorizer(max_features=max_features,lowercase=True,analyzer='word',ngram_range = (1,1),stop_words=stops,use_idf=True)     
        X = vec1.fit_transform(X_sents).toarray()
        # print('vocab = ',vec1.vocabulary_)
        with open(vectorizer1,'wb+') as f:
            pickle.dump(vec1,f)
    else:
        with open(vectorizer1,'rb') as f:
            vec1 = pickle.load(f)
        X = vec1.transform(X_sents).toarray()
    return X

def custom_one_hot_enc(Y_intents):
    # print(f'Y_intents = {Y_intents}')
    intents = list(set(Y_intents))
    print(f'intents = {intents}')
    intent_dict = {}
    for i in range(0,len(intents)):
        intent_dict[intents[i]] = i

    print(intent_dict)
    tempdf = pd.DataFrame()
    tempdf['intent'] = Y_intents
    def encode_class(x):
        if x in intent_dict:
            return intent_dict[x]
        else:
            return np.nan
    tempdf['id'] = tempdf['intent'].apply(encode_class)
    intent_df = tempdf.drop_duplicates()
    intent_df.to_excel(intent_encodngs)
    print('tempdf')
    print(tempdf.head())
    return np.asarray(tempdf['id'].values.tolist())


###########################
### Tuning Vectorizer with Model using secant method
### Naive Bayes Method
def model_training(X_sents,y_intents,iterations,min_feat,max_feat):
    w = int((min_feat + max_feat )/2)
    params = {}
    score = 0.0
    clf = None
    for i in range(0,iterations):
        if i>=2:
            if params['fb']==params['fb']:
                w = int(w)
                break
            else:
                temp = (params['fb']*params['a'] - params['fa']*params['b']) / (params['fb'] - params['fa'])
                if temp<1:
                    break
                w = int(temp)

        X = vectorize_sents(X_sents,max_features = w,fit=True)
        y = custom_one_hot_enc(y_intents)
        X = np.asarray(X)
        print('X:')
        pp.pprint(X)
        print(X.shape)
        # print('X0 = ',X[0])
        print('Y = ',y)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        clf = MultinomialNB()
        clf.fit(X_train, y_train)
        y_pred = clf.predict(X_test)
        P = precision_score(y_test, y_pred,average='micro')
        R = recall_score(y_test, y_pred,average='micro')
        B = 2
        score = (1+B*B)*(P*R)/((B*B*P)+R)
        if i==0:
            params['a'] = w
            params['fa'] = score
        elif i==1:
            params['b'] = w
            params['fb'] = score
        elif i>1:
            if params['fb']>params['fa']:
                params['a'] = w
                params['fa'] = score
                w = params['b']
            elif params['fb']<params['fa']:
                params['b'] = w
                params['fb'] = score
                w = params['a']
            else:
                w = min(params['a'],params['b'])
                break


    with open(clf_save_file,'wb+') as f:
        pickle.dump(clf,f)
    print('model saved w = ',w,' P = ',P,' R = ',R,' F1_beta score = ',score)

def get_intent(s1):
    clf1 = None
    s1 = clean_sents(s1)
    s1 = lm_each(s1)
    X_test = vectorize_sents([s1,],fit=False)
    print('X_test shape = ',X_test.shape)
    with open(clf_save_file,'rb+') as f:
        clf1 = pickle.load(f)
    y_pred = clf1.predict(X_test)   
    print('for input = ',s1,' y_pred = ',y_pred)
    return y_pred

def get_reply(s1):
    print('get_reply called')
    y_pred = get_intent(s1)
    if len(y_pred)>0:
        y_pred = y_pred[0]
    else:
        y_pred = 2
    intent_df = pd.read_excel(intent_encodngs)
    print(f'y_pred = {y_pred}')
    intent_pred = intent_df[intent_df['id']==y_pred]['intent'].unique()
    print('intent_pred = ',intent_pred)
    intent_pred = intent_pred.tolist()[0]
    reply_df = pd.read_excel(intent_reply_data)
    temp_df = reply_df[reply_df['intent'] == intent_pred]
    print(temp_df.head())
    reply = temp_df['ans'].sample(n=1,frac=None,replace=False).values.tolist()[0] 
    print(type(reply))
    print('for intent_pred = ',intent_pred,' reply= ',reply)
    return reply

class UserName:
    def __init__(self,name):
        self.name = name

def main():
    iterations =20
    max_feat = 100
    min_feat = 10
    print('iterations = ',iterations)
    df,df_ans = extract()
    X_sents,y_intents = preprocess_data()
    model_training(X_sents,y_intents,iterations,min_feat,max_feat)

def test1():
    s1 = 'This is Adam'
    get_reply(s1)

    
if __name__=='__main__':
    main()
    # test1()
