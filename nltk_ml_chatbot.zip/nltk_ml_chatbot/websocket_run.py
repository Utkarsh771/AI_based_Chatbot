import asyncio
from websockets import serve
from nlp_main import get_reply


### same client for fastapi websocket

async def echo(websocket,path):
    async for message in websocket:
        reply = None
        reply = get_reply(message)
        print('reply = ',reply)
        while True:
            if reply:
                await websocket.send(reply)
                print('reply sent= ',reply)
                reply = None
                break
            else:
                asyncio.sleep(1)


async def serving():
    async with serve(echo, "localhost", 7001):
        print('listening...')
        await asyncio.Future()  # run forever

def main():
    asyncio.run(serving())


if __name__=='__main__':
    main()